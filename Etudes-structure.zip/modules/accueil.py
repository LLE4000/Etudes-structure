import streamlit as st

def show():
    st.title("Bienvenue dans l'application de calcul de structure")
    st.markdown("Sélectionnez un outil dans le menu à gauche.")
