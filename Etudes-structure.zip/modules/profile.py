import streamlit as st

def show():
    st.title("Dimensionnement des profils métalliques")
    st.write("À venir...")
